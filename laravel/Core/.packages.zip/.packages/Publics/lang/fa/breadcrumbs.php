<?php
    return [
        // ******************* login Admin ************************
        'panel' => 'پنل کاربری',
        'editProfile' => 'ویرایش پروفایل',
        'blogComments' => 'پیام های وبلاگ',
        'ticketSubjects' => 'موضوعات تیکت',
        'waitingTickets'=>'تیکت های نیاز به بررسی',
    ];
?>
