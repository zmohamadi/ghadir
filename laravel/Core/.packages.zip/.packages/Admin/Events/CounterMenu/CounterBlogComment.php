<?php

namespace Admin\Events\CounterMenu;

use Illuminate\Queue\SerializesModels;

class CounterBlogComment
{
    use SerializesModels;

    /**
     * title in table base_counts For update count : 'blog-comments'
     */
}
