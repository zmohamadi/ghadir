'use client';

import {Data, useData} from "@/lib/data";
// import {Data, DataObj, useData} from "@/lib/dataFetch";
export {Data, useData};
