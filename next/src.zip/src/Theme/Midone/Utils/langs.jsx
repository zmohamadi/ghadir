'use client'

let langs = {
  public:{
    // 'error-422' : 'داده ها به درستی ارسال نگردیده است!!',
    // 'error-401' : 'مجوز دسترسی شما به سایت منقضی شده است، لطفا مجدد وارد شوید!!',
    // 'error-501' : 'خطای سرور، لطفا مورد را به مدیر سامانه گزارش دهید!!',
    // 'error message' : 'پیغام خطا',
    // 'message' : 'پیغام',
    // 'Connection error' : 'خطا در اتصال',
    // 'no data' : 'داده ای جهت نمایش وجود ندارد...',
    // 'Are you sure you want to delete?' : 'آیا از حذف مطمئن هستید؟',
    // 'The record was not found, probably deleted already' : 'رکورد مورد نظر یافت نشد، احتمالا قبلا حذف گردیده است!!',
    // 'ASC' : 'صعودی',
    // 'DESC' : 'نزولی',
    // 'Order By' : 'ترتیب بر اساس',
    // 'Default Field' : 'فیلد پیش فرض',
    // 'Search' : 'جستجو...',
    // 'Display' : 'نمایش',
    // 'From' : 'از',
    // 'Item' : 'مورد',
    // 'New Item' : 'جدید',
    // 'exit' : 'خروج',
    // 'save_message' : 'با موفقیت ثبت شد!!!',
    // 'row' : 'ردیف',
    // 'order' : 'ترتیب بر اساس',
  }
};

export {langs};
