'use client';

export const CheckDate = ({current = "",date = "",link = ""}) => {
  return(
      // (date )
      <div className={'col-span-12 '+(border?'border-t-2':'')}></div>
  );
}
