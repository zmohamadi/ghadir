"use client"
/*  ----- TAB Components ----- */
export * from './Tab';
export * from './TabBody';
export * from './TabHeader';
export * from './TabList';
export * from './TabPanel';