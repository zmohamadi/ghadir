"use client"

import {SystemForm} from "./Form";

const NewSystemPage = ()=>{
    return <>
        <SystemForm />
    </>
}

export default NewSystemPage;