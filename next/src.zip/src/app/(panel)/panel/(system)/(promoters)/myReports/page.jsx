"use client";

import { List } from "@/Components/Reports/List";
export default function Page() {
    return <List />;
}