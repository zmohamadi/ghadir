"use client";
import { Form } from "@/Components/Promotions/Form";
export default function page(){
    return(
        <Form />
    );
}