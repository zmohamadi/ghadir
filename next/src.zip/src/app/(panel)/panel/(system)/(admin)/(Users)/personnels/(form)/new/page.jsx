"use client";
import Form from '@/app/(panel)/panel/(system)/(admin)/(Users)/personnels/(form)/form';

export default function New(){
    return(
        <div>
            <Form />
        </div>
    );
}