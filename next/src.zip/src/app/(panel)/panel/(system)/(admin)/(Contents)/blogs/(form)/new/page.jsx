"use client";

import Form from '@/Components/Blog/Form';

export default function New(){
    return(
        <Form />
    );
}