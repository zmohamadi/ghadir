"use client";
import { List } from "@/Components/Promoters/List";
export default function page(){
return<List />;
}