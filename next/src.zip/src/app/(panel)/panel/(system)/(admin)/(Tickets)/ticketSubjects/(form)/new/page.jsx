"use client";

import Form from '@/Components/TicketSubject/Form';

export default function New(){
    
    return(
        <Form />
    );
}