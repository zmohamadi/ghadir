"use client";
import Form from '../form';

export default function New(){
    return(
        <div>
            <Form></Form>
        </div>
    );
}