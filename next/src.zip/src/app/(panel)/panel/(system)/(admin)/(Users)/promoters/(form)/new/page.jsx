"use client";
import { Form } from "@/Components/Promoters/Form";

export default function page(){
    return(
        <div>
            <Form />
        </div>
    );
}