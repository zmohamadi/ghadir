"use client";

import {List as Items} from '@/Components/Blog/Comments/List';

export default function List(){
    return(
        <Items />
    );
}