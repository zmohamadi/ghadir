"use client";

import { List } from "@/Components/Supports/List";

export default function Page() {

    return <List panel="admin" />;
}
