// app/layout.jsx
export default function RootLayout({ children }) {
    return (<>
      {children}
    </>);
  }
  